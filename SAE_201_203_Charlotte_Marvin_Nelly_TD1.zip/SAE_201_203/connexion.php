<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

$host = 'localhost';
$user = 'root';
$pass = 'root';
$db = 'SAE-STAGE-MMI';
$port='8889';

try {

$bdd = new PDO("mysql:host=$host;port=$port;dbname=$db;charset=utf8", $user, $pass);
$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
    echo "Erreur lors de la connexion : " . $e->getMessage();

}
?>

<doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="margin:0; padding:0; display:flex; flex-direction:column;">
    
    <nav class = "navbar">
        <img src="logo.png" alt="Logo" class="footer-logo">
    </nav>
    <section class="connexion">
        <div class="connexion-card">
            <h2>Connexion</h2>
            <form action="traitement_connexion.php" method="post">
                <label for="email">Email :</label>
                <input type="email" id="email" name="email" placeholder="etudiant@univ-eiffel.fr" required>

                <label for="password">Mot de passe :</label>
                <input type="password" id="password" name="password" placeholder="Votre mot de passe" required>

                <select id="role" name="role" required>
                    <option value="">Sélectionnez votre rôle</option>
                    <option value="etudiant">Étudiant</option>
                     <option value="enseignant">Enseignant</option>
                    <option value="admin">Admin</option>

                </select>

                <button type="submit" class="btn-primary">Se connecter</button>
            </form>
            <p class="form-footer"><a href=inscription.html>Créer un compte</a></p>
        </div>
    </section>


</body>
</html>















