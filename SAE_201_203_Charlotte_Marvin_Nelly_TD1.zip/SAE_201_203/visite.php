


<?php
session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.html");
    exit();
}

require 'bdd.php';


$id_prof = $_SESSION['user_id'];


if(isset($_POST['action']) && $_POST['action'] === 'Enregistrer') {
  
  $id_stage = $_POST['id_stage'];
  $date_visite = $_POST['date_visite'];
  $rapport = $_POST['rapport'];


  $req = $bdd->prepare("INSERT INTO visite_suivi (date_visite, rapport , id_stage ,id_enseignant ) VALUES ( ? ,?, ?, ?)");
  $req->execute([$date_visite,$rapport, $id_stage, $id_prof]);

  header("location: visite.php");
  exit();
}


$req_stagiaires = $bdd->prepare("SELECT stage.id AS id_stage , etudiant.nom, etudiant.prenom FROM stage
JOIN etudiant ON stage.matricule_etudiant = etudiant.matricule
LEFT JOIN visite_suivi ON stage.id = visite_suivi.id_stage
WHERE visite_suivi.id_enseignant = ? OR visite_suivi.id_enseignant IS NULL");
$req_stagiaires->execute([$id_prof]);
$stagiaires = $req_stagiaires->fetchAll();


$req_visites = $bdd->prepare("SELECT visite_suivi.*, etudiant.nom, etudiant.prenom, offres_stages.entreprise 
FROM visite_suivi
JOIN stage ON visite_suivi.id_stage = stage.id
JOIN etudiant ON stage.matricule_etudiant = etudiant.matricule
LEFT JOIN offres_stages ON stage.id_offre =  offres_stages.id
WHERE visite_suivi.id_enseignant = ?
ORDER BY date_visite DESC");

$req_visites->execute([$id_prof]);
$liste_visites = $req_visites->fetchAll();

?>





<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Visites de suivi</title>
    <link rel="stylesheet" href="visite.css">
</head>
<body>

  <nav class="navbar">
    <img src="logo.png" alt="Université Gustave Eiffel" class="footer-logo">
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="dashboard_enseignant.php">Dashboard</a></li>
      <li><a href="stagiaires.php">Mes stagiaires</a></li>
      <li><a href="visite.php" class="active">Visites de suivi</a></li>
      <li><a href="evaluation_enseignant.php">Évaluations</a></li>
      <li><a href="problemes_enseignant.php">Signalement</a></li>
    </ul>

    <div class="sidebar-footer">
      <div class="user-name"><?php echo $_SESSION['prenom']." ".$_SESSION['nom']; ?></div>
      <div class="user-role">Enseignant</div>
    </div>
  </aside>

  <div class="main">
    <div class="topbar">
      <h1>Visites de suivi</h1>
    </div>

    <form action="visite.php" method="post">
      <div class="card">
        <div class="card-title">Remplir le formulaire de visite</div>

        <label for="stagiaires">Stagiaires :</label>
        <select id="stagiaires" name="id_stage" required>
          <option value="">Sélectionnez un stagiaire</option>
          <?php foreach ($stagiaires as $s): ?>
          <option value="<?php echo $s['id_stage']; ?>">
            <?php echo $s['nom']." ".$s['prenom']; ?>
          </option>
          <?php endforeach; ?>
        </select>

        <label for="date">Date de la visite :</label>
        <input type="date" id="date" name="date_visite" required>

        <label for="description">Rapport de la visite :</label>
        <textarea id="description" name="rapport" placeholder="Observations..." required></textarea>

        <button type="submit" class="btn-primary" name="action" value="Enregistrer">Enregistrer</button>
      </div>
    </form>

    <div class="card-2">
      <div class="card-title">Visites à faire</div>
      <?php if (empty($liste_visites)): ?>
      <div class="card-3">
        <div class="nom-stagiaire">Aucune visite à faire</div>
      </div>
      <?php else: ?>
      <?php foreach ($liste_visites as $v): ?>
      <div class="card-3">
        <div class="nom-stagiaire"><?php echo $v['nom']." ".$v['prenom']; ?></div>
        <div class="date-visite"><?php echo $v['date_visite']; ?></div>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>

  </div>

</body>
</html>

