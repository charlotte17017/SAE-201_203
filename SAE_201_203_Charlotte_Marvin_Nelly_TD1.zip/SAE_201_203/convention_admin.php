
<?php

session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.html");
    exit();
}

require 'bdd.php';


try {
if (isset($_POST['action']) && $_POST['action'] === 'valider') {
    $matricule = $_POST['id_etudiant'];
    $req = $bdd->prepare("UPDATE stage SET convention = 'Validée' WHERE id = ?");
    $req->execute([$matricule]);

}

if (isset($_POST['action']) && $_POST['action'] === 'refuser') {
    $matricule = $_POST['id_etudiant'];
    $req = $bdd->prepare(" DELETE FROM stage WHERE id = ? ");
    $req->execute([$matricule]);

}


    $req_attente  = $bdd->prepare("SELECT stage.id AS id_stage, etudiant.nom, etudiant.prenom ,offres_stages.entreprise AS nom_entreprise 
    FROM stage
    JOIN etudiant ON stage.matricule_etudiant = etudiant.matricule
    JOIN offres_stages ON stage.id_offre =  offres_stages.id
    WHERE stage.convention IS NULL OR stage.convention != 'Validée'");
    $req_attente->execute();
    $conventions_attente = $req_attente->fetchAll();


    $req_valides =$bdd->prepare("SELECT stage.id AS id_stage, etudiant.nom, etudiant.prenom ,offres_stages.entreprise AS nom_entreprise 
    FROM stage
    JOIN etudiant ON stage.matricule_etudiant = etudiant.matricule
    JOIN offres_stages ON stage.id_offre =  offres_stages.id
    WHERE stage.convention = 'Validée'");
    $req_valides->execute();
    $etudiants_valides = $req_valides->fetchAll();

    $req_stages= $bdd->prepare("SELECT stage.*, etudiant.nom, etudiant.prenom,offres_stages.entreprise AS nom_entreprise 
     FROM stage
    JOIN etudiant ON stage.matricule_etudiant = etudiant.matricule
    JOIN offres_stages ON stage.id_offre =  offres_stages.id");
    $req_stages->execute();
    $liste_stages = $req_stages->fetchAll();

} catch (PDOException $e) {
    echo "Erreur lors de la connexion : " . $e->getMessage();
}

?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Convention</title>
    <link rel="stylesheet" href="convention_admin.css">
</head>
<body>

  <nav class="navbar">
    <img src="logo.png" alt="Université Gustave Eiffel" class="nav-logo">
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="dashboard_admin.php">Dashboard</a></li>
      <li><a href="offre_admin.php">Offres de stage</a></li>
      <li><a href="convention_admin.php" class="active">Convention</a></li>
      <li><a href="utilisateurs_admin.php">Utilisateurs</a></li>
    </ul>

    <div class="sidebar-footer">
      <div class="user-name"><?php echo $_SESSION['prenom']." ".$_SESSION['nom']; ?></div>
      <div class="user-role">Administrateur</div>
    </div>
  </aside>

    <div class="main">
    <div class="topbar">
      <div class="topbar-title">Convention</div>
    </div>

    <div class="grid-2">
      <div class="card">
        <div class="card-title">En attente</div>
        <?php foreach ($conventions_attente as $etudiant) : ?>
        <div class="info-card">
          <p class="info-label"><?php echo $etudiant['prenom']." ".$etudiant['nom']; ?></p>
          <span class="info-value"><?php echo $etudiant['nom_entreprise']; ?></span>
          <form method="post">
            <input type="hidden" name="id_etudiant" value="<?php echo $etudiant['id_stage']; ?>">
            <button type="submit" name="action" value="valider" class="btn-attente-valide">Validé</button>
            <button type="submit" name="action" value="refuser" class="btn-attente-refuse">Refusé</button>
          </form>
        </div>
        <?php endforeach; ?>
      </div>

      <div class="card">
        <div class="card-title">Convention validée</div>
        <?php foreach ($etudiants_valides as $etudiant): ?>
        <div class="info-card">
          <p class="info-label"><?php echo $etudiant['prenom']." ".$etudiant['nom']; ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="card-2">
      <div class="card-title">Convention validée</div>
      <table class="table">
        <thead>
          <tr>
            <th>Nom de l'étudiant</th>
            <th>Entreprise</th>
            <th>Date de début</th>
            <th>Date de fin</th>
            <th>Statut</th>
            <th>Durée</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($liste_stages as $stage): ?>
          <tr>
            <td><?php echo $stage['prenom']." ".$stage['nom']; ?></td>
            <td><?php echo $stage['nom_entreprise']; ?></td>
            <td><?php echo $stage['date_debut']; ?></td>
            <td><?php echo $stage['date_fin']; ?></td>
            <td><?php echo $stage['convention'] ? $stage['convention'] : 'En attente'; ?></td>
            <td></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

  </div>

</body>
</html>