
<?php

session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.html");
    exit();
}

require 'bdd.php';

$id_prof = $_SESSION['user_id'];

try {
    $req = $bdd->prepare("SELECT COUNT(id_stage) as total FROM visite_suivi WHERE id_enseignant= ?");
    $req->execute([$id_prof]);
    $nb_stagiaires = $req->fetch()['total'];

    $req = $bdd->prepare("SELECT COUNT(*) as total FROM visite_suivi WHERE id_enseignant= ?");
    $req->execute([$id_prof]);
    $nb_visite = $req->fetch()['total'];
    

    $req = $bdd->prepare("SELECT COUNT(*) as total FROM problemes 
    JOIN stage ON problemes.id_stage = stage.id
    JOIN visite_suivi ON stage.id = visite_suivi.id_stage
    WHERE visite_suivi.id_enseignant= ?");
    $req->execute([$id_prof]);
    $nb_signalement = $req->fetch()['total'];

    $req = $bdd->prepare("SELECT COUNT(*) as total FROM offres_stages");
    $req->execute();
    $nb_offre = $req->fetch()['total'];




} catch (PDOException $e) {
    echo "Erreur lors de la connexion : " . $e->getMessage();
}

?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="dashboard_enseignant.css">
</head>
<body>
  <nav class="navbar">
    <img src="logo.png" alt="Logo" class="footer-logo">
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="Dashboard.php" class="active"> Dashboard</a></li>
      <li><a href="stagiaires.php">Mes stagiaires</a></li>
      <li><a href="visite.php">Visites de suivi</a></li>
      <li><a href="evaluation_enseignant.php">Évaluations</a></li>
      <li><a href="problemes_enseignant.php">Signalement</a></li>

    </ul>
     <div class="sidebar-user">

      <div class="user-info">
        <div class="user-name"> <?php echo $_SESSION['prenom']. " ". $_SESSION['nom'];?></div>
        <div class="user-role">Enseignant</div>
      </div>
    </div>
  </aside>

  

<div class="main">
      <div class="topbar">
      <span class="topbar-title">Dashboard</span>
      <span class="topbar-info"> Année 2025-2026</span>
    </div>



  <div class="Bannière">
    <div>
      <h2>Bienvenue, <?php echo $_SESSION['prenom']. " ". $_SESSION['nom'];?></h2>
      <p>Voici un aperçu de vos activités récentes et de vos statistiques.</p>
    </div>

  </div>




  <div class="stats">
    <div class="stat-card">
      <span class="stat">Stagiaire suivis</span>
      <span class="stat-value"><?php echo $nb_stagiaires;?></span>
    </div>

    <div class="stat-card">
      <span class="stat">Visites à faire</span>
      <span class="stat-value"><?php echo $nb_visite;?></span>
    </div>

    <div class="stat-card">
      <span class="stat">Problemes traités</span>
      <span class="stat-value"><?php echo $nb_signalement;?></span>
     </div>
  </div>

 
    <div class="quick-actions">
      <a href="stagiaires.html" class="quick-action">
        <div class="stat">Mes stagiaires</div>
        <span class="stat-value"><?php echo $nb_stagiaires;?></span>

        
      </a>

      <a href="visite.html" class="quick-action">
        <div class="stat">Visites de suivi</div>
        <span class="stat-value"><?php echo $nb_visite;?></span>

      </a>

      <a href="signalement_enseignant.html" class="quick-action">
        <div class="stat">Problemes traités</div>
        <span class="stat-value"><?php echo $nb_signalement;?></span>

      </a>
    </div>
</div>
</body>
</html>
