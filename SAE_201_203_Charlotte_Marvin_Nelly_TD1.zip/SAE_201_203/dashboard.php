<?php
session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.php");
    exit();
}

$host = "localhost";
$dbname = "SAE-STAGE-MMI";
$user = "root";
$password = "root";

try {
    $pdo = new PDO("mysql:host=$host;port=8889;dbname=$dbname;charset=utf8", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

$matricule = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT s.*, so.note_finale, so.date_soutenance, so.date_rapport 
                        FROM stage s 
                        LEFT JOIN soutenance so ON so.id_stage = s.id
                        WHERE s.matricule_etudiant = ?");
$stmt->execute([$matricule]);
$stage = $stmt->fetch(PDO::FETCH_ASSOC);

$stmt2 = $pdo->prepare("SELECT date_visite FROM visite_suivi 
                         WHERE id_stage = ? 
                         AND date_visite >= CURDATE() 
                         ORDER BY date_visite ASC LIMIT 1");
$stmt2->execute([$stage['id'] ?? 0]);
$visite = $stmt2->fetch(PDO::FETCH_ASSOC);

$duree = null;
if ($stage && $stage['date_debut'] && $stage['date_fin']) {
    $debut = new DateTime($stage['date_debut']);
    $fin = new DateTime($stage['date_fin']);
    $mois = $debut->diff($fin)->m + ($debut->diff($fin)->y * 12);
$duree = $mois . ' mois';
}

$convention = $stage['convention'] ?? 'Non renseigné';
$note = $stage['note_finale'] ? number_format($stage['note_finale'], 2) . ' / 20' : 'Non renseignée';
$soutenance = $stage['date_soutenance'] ? date('d/m/Y', strtotime($stage['date_soutenance'])) : 'Non renseignée';
$prochaine_visite = $visite ? date('d/m/Y', strtotime($visite['date_visite'])) : 'Non renseignée';
$date_rapport = $stage['date_rapport'] ? date('d/m/Y', strtotime($stage['date_rapport'])) : 'Non renseignée';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="Dashboard.css">
</head>
<body>

  <nav class="navbar">
    <img src="logo.png" alt="Logo" class="footer-logo">
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="offres.php">Offres de stage</a></li>
      <li><a href="dashboard.php" class="active">Dashboard</a></li>
      <li><a href="convention.php">Mon stage</a></li>
      <li><a href="evaluation.php">Mes évaluations</a></li>
      <li><a href="signalement.php">Signaler un problème</a></li>
      <li><a href="historique.php">Historique</a></li>
    </ul>
    <div class="sidebar-user">
      <div class="user-name"><?php echo $_SESSION['prenom'] . ' ' . $_SESSION['nom']; ?></div>
      <div class="user-role">Étudiant MMI</div>
    </div>
  </aside>

  <div class="main">

    <div class="topbar">
      <span class="topbar-title">Dashboard</span>
      <span class="topbar-info">Année 2025-2026</span>
    </div>

    <div class="Bannière">
      <div>
        <h2>Bienvenue, <?php echo $_SESSION['prenom'] . ' ' . $_SESSION['nom']; ?></h2>
        <p>Voici un aperçu de vos activités.</p>
      </div>
    </div>

    <div class="stats">
      <div class="stat-card">
        <span class="stat">Mon stage</span>
        <span class="stat-value"><?php echo $duree ?? 'Non renseigné'; ?></span>
      </div>
      <div class="stat-card">
        <span class="stat">Statut de la convention</span>
        <span class="stat-value"><?php echo $convention; ?></span>
      </div>
      <div class="stat-card">
        <span class="stat">Note finale</span>
        <span class="stat-value"><?php echo $note; ?></span>
      </div>
    </div>

    <div class="quick-actions">
      <a href="#" class="quick-action">
        <span class="stat">Prochaine visite enseignant</span>
        <span class="stat-value"><?php echo $prochaine_visite; ?></span>
      </a>
      <a href="offres.php" class="quick-action">
        <span class="stat">Prochaine soutenance</span>
        <span class="stat-value"><?php echo $soutenance; ?></span>
      </a>
      <a href="evaluation.html" class="quick-action">
        <span class="stat">Prochain rapport à rendre</span>
        <span class="stat-value"><?php echo $date_rapport; ?></span>
      </a>
    </div>

  </div>

</body>
</html>