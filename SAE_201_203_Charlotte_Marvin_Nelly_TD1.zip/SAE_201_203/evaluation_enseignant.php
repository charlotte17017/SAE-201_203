<?php
session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.html");
    exit();
}

require 'bdd.php';

$id_prof = $_SESSION['user_id'];

if(isset($_POST['action']) && $_POST['action'] === 'Enregistrer') {
  
  $id_stage = $_POST['stagiaires'];
  $date_soutenance = $_POST['date_soutenance'];
  $note_rapport = $_POST['note'];
  $note_oral = $_POST['note_oral'];
  $rapport_visite = $_POST['rapport_visite'];
  $commentaire_oral = $_POST['description_oral'];
  $commentaire_rapport = $_POST['description_commentaire'];

 

$note_finale = ($note_rapport + $note_oral ) / 2;

$req = $bdd->prepare("INSERT INTO  soutenance (date_soutenance, note_rapport, note_oral, note_finale, oral , rapport, id_stage ) 
VALUES ( ?, ?, ?, ?, ?, ?, ?)");
$req->execute([$date_soutenance, $note_rapport, $note_oral, $note_finale, $commentaire_oral, $commentaire_rapport, $id_stage]);

header("location: evaluation_enseignant.php");
exit();
}


$req_stagiaires = $bdd->prepare("SELECT stage.id AS id_stage , stage.sujet , stage.id_maitre_stage , etudiant.nom , etudiant.prenom, offres_stages.entreprise
FROM stage 
JOIN etudiant ON stage.matricule_etudiant =etudiant.matricule
LEFT JOIN offres_stages On stage.id_offre = offres_stages.id");

$req_stagiaires->execute();
$stagiaires = $req_stagiaires->fetchAll();

?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Évaluations</title>
    <link rel="stylesheet" href="evaluation_enseignant.css">
</head>
<body>

  <nav class="navbar">
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="dashboard_enseignant.php">Dashboard</a></li>
      <li><a href="stagiaires.php">Mes stagiaires</a></li>
      <li><a href="visite.php">Visites de suivi</a></li>
      <li><a href="evaluation_enseignant.php" class="active">Évaluations</a></li>
      <li><a href="problemes_enseignant.php">Problèmes signalés</a></li>
    </ul>
    <div class="sidebar-user">
      <div class="user-info">
        <div class="user-name"><?php echo $_SESSION['prenom'] . ' ' . $_SESSION['nom']; ?></div>
        <div class="user-role">Enseignant</div>
      </div>
    </div>
  </aside>

  <div class="main">
  <div>
    <h1>Saisir les notes de l'évaluation</h1>
    <p>Remplissez le formulaire pour enregistrer l'évaluation d'un stagiaire.</p>
  </div>
  <div class="topbar">
    <span class="topbar-info">Année 2025-2026</span>
  </div>

    <form action="" method="post">
      <div class="card">
        <div class="card-title">Évaluations</div>
        <label for="stagiaires">Stagiaires :</label>
        <select id="stagiaires" name="stagiaires">
          <option value="">Sélectionnez un stagiaire</option>
          <?php foreach ($stagiaires as $s): ?>
            <option value="<?php echo $s['id_stage']; ?>">
              <?php echo $s['nom'] . ' ' . $s['prenom']; ?>
            </option>
          <?php endforeach; ?>
        </select>

        <label for="date_visite">Date de la visite :</label>
        <input type="date" id="date_visite" name="date_visite" required>

        <label for="rapport_visite">Rapport de la visite :</label>
        <textarea id="rapport_visite" name="rapport_visite" placeholder="Observations..." required></textarea>

        <label for="date_soutenance">Date de la soutenance :</label>
        <input type="date" id="date_soutenance" name="date_soutenance" required>
      </div>

      <div class="card-2">
        <div class="card-title">Note du stagiaire</div>
        <div class="info-card-2">
          <div class="info-label">Note du rapport</div>
          <input type="number" id="note" name="note" min="0" max="20" required>
          <p>/ 20</p>

          <div class="info-label">Note de l'oral</div>
          <input type="number" id="note_oral" name="note_oral" min="0" max="20" required>
          <p>/ 20</p>

          <div class="info-label">Note finale</div>
          <input type="number" id="note_finale" name="note_finale" readonly>
          <p>/ 20</p>

          <div class="info-label">Commentaire pour l'oral</div>
          <textarea id="description_oral" name="description_oral" placeholder="Observations..." required></textarea>

          <div class="info-label">Commentaire rapport</div>
          <textarea id="description_commentaire" name="description_commentaire" placeholder="Observations..." required></textarea>

          <button type="submit" class="btn-primary" name="action" value="Enregistrer">Enregistrer</button>
        </div>
      </div>
    </form>
  </div>

  <script src="evaluation_enseignant.js"></script>
</body>
</html>