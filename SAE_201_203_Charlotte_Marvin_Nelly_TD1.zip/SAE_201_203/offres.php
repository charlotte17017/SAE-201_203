<?php
session_start();

if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("Location: connexion.php");
    exit();
}

require 'bdd.php';

$search = $_GET['search'] ?? '';
$lieu = $_GET['lieu'] ?? '';
$duree = $_GET['duree'] ?? '';

$sql = "SELECT * FROM offres_stages WHERE 1=1";
$params = [];

if ($search) {
    $sql .= " AND intitule LIKE ?";
    $params[] = '%' . $search . '%';
}
if ($lieu) {
    $sql .= " AND lieu LIKE ?";
    $params[] = '%' . $lieu . '%';
}
if ($duree) {
    $sql .= " AND duree = ?";
    $params[] = $duree;
}

$stmt = $bdd->prepare($sql);
$stmt->execute($params);
$offres = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!doctype html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Offres de stage</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="offres.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@700;800&family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body>

  <nav class="navbar">
    <div class="nav-logo">
      <img src="logo.png" alt="Logo" class="footer-logo">
    </div>
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="offres.php" class="active">Offres de stage</a></li>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="convention.php">Mon stage</a></li>
      <li><a href="evaluation.php">Mes évaluations</a></li>
      <li><a href="signalement.php">Signaler un problème</a></li>
      <li><a href="historique.php">Historique</a></li>
    </ul>
    <div class="sidebar-user">
      <div class="user-name"><?php echo htmlspecialchars($_SESSION['prenom'] . ' ' . $_SESSION['nom']); ?></div>
      <div class="user-role">Étudiant MMI</div>
    </div>
  </aside>

  <main class="main">
    <div class="topbar">
      <h1 class="topbar-title">Offres de stage</h1>
    </div>

    <p>Consultez et recherchez parmi les offres déposées par les entreprises partenaires.</p>

    <div class="content">

      <form method="GET" action="offres.php">
        <div class="filters">
          <input type="text" name="search" placeholder="Rechercher un intitulé..." value="<?php echo htmlspecialchars($search); ?>">
          <input type="text" name="lieu" placeholder="Lieu" value="<?php echo htmlspecialchars($lieu); ?>">
          <select name="duree">
            <option value="">Toutes les durées</option>
            <option value="1 mois" <?php echo $duree === '1 mois' ? 'selected' : ''; ?>>1 mois</option>
            <option value="2 mois" <?php echo $duree === '2 mois' ? 'selected' : ''; ?>>2 mois</option>
            <option value="3 mois" <?php echo $duree === '3 mois' ? 'selected' : ''; ?>>3 mois</option>
          </select>
          <button type="submit" class="btn-filter">Filtrer</button>
        </div>
      </form>

      <div class="cards">
        <?php if (empty($offres)): ?>
          <p>Aucune offre trouvée.</p>
        <?php else: ?>
          <?php foreach ($offres as $offre): ?>
            <div class="card">
              <div class="card-header">
                <div>
                  <h3><?php echo htmlspecialchars($offre['intitule']); ?></h3>
                  <p class="company"><?php echo htmlspecialchars($offre['entreprise']); ?></p>
                </div>
                <span class="salary"><?php echo $offre['remuneration'] ? htmlspecialchars($offre['remuneration']) . '€/mois' : ''; ?></span>
              </div>
              <p class="card-meta"><?php echo htmlspecialchars($offre['lieu']); ?> &nbsp;·&nbsp; <?php echo htmlspecialchars($offre['duree']); ?></p>
              <div class="tags">
                <?php 
                  if ($offre['competences']) {
                    $tags = explode(',', $offre['competences']);
                    foreach ($tags as $tag) {
                      echo '<span class="tag">' . htmlspecialchars(trim($tag)) . '</span>';
                    }
                  }
                ?>
              </div>
              <div class="card-footer">
                <span class="badge disponible">Disponible</span>
                <a href="details_offre.php?id=<?php echo $offre['id']; ?>" class="btn-voir">Voir l'offre</a>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

    </div>
  </main>

</body>
</html>