<?php
session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.php");
    exit();
}

$host = 'localhost';
$user = 'root';
$pass = 'root';
$db = 'SAE-STAGE-MMI';
$port = '8889';

try {
    $bdd = new PDO("mysql:host=$host;port=$port;dbname=$db;charset=utf8", $user, $pass);
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Erreur : " . $e->getMessage());
}

$stmt = $bdd->prepare("
    SELECT p.description, p.date_probleme, e.nom, e.prenom
    FROM problemes p
    JOIN stage s ON p.id_stage = s.id
    JOIN etudiant e ON s.matricule_etudiant = e.matricule
    ORDER BY p.date_probleme DESC
");
$stmt->execute();
$problemes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Problèmes signalés</title>
    <link rel="stylesheet" href="problemes_enseignant.css">
</head>
<body>

  <nav class="navbar">
    <img src="logo.png" alt="Université Gustave Eiffel" class="footer-logo">
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="dashboard_enseignant.php">Dashboard</a></li>
      <li><a href="stagiaires.php">Mes stagiaires</a></li>
      <li><a href="visite.php">Visites de suivi</a></li>
      <li><a href="evaluation_enseignant.php">Évaluations</a></li>
      <li><a href="problemes_enseignant.php"class="active">Problèmes signalés</a></li>
    </ul>
    <div class="sidebar-user">
      <div class="user-info">
        <div class="user-name"><?= htmlspecialchars($_SESSION['prenom'] . ' ' . $_SESSION['nom']) ?></div>
        <div class="user-role">Enseignant</div>
      </div>
    </div>
  </aside>

  <div class="main">
    <h1>Problèmes signalés</h1>
    <p>Voici un aperçu des problèmes signalés par vos étudiants durant leur stage.</p>
    <div class="topbar">
    <span class="topbar-info"></span>
</div>
    
    <div class="stats">
      <?php if (empty($problemes)): ?>
        <p style="color: var(--gris-texte);">Aucun problème signalé pour le moment.</p>
      <?php else: ?>
        <?php foreach ($problemes as $p): ?>
        <div class="stat-card">
          <div class="card-header">
            <span class="card-label">Élève :</span>
            <span class="card-info"><?= htmlspecialchars($p['prenom'] . ' ' . $p['nom']) ?></span>
          </div>
          <div class="card-body">
            <span class="card-label">Description :</span>
            <p class="card-description"><?= htmlspecialchars($p['description']) ?></p>
          </div>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

</body>
</html>