<?php

session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Problèmes signalés</title>
    <link rel="stylesheet" href="problemes_enseignant.css">
</head>
<body>
   <nav class="navbar">
    <img src="logo.png" alt="Université Gustave Eiffel" class="footer-logo">
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>
  

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="dashboard_enseignant.php"> Dashboard</a></li>
      <li><a href="stagiaires.php">Mes stagiaires</a></li>
      <li><a href="visite.php">Visites de suivi</a></li>
      <li><a href="evaluation_enseignant.php">Évaluations</a></li>
      <li><a href="problèmes_enseignant.php"class="active">Problèmes signalés</a></li>
    </ul>
     <div class="sidebar-user">
      <div class="user-info">
        <div class="user-name">à modifier</div>
        <div class="user-role">Enseignant</div>
      </div>
    </div>
  </aside>

  

<div class="main">



    <h1><span class="dashboard">Problèmes signalés</span></h1>
    <p>Voici un aperçu des problèmes signalés par vos étudiants durant leur stage.</p>
    <div class="topbar">

  <div class="stats">
    <div class="stat-card">
      <span class="stat">Nom étudiant (a modifier)</span>
      <span class="stat-value">à modifier</span>
    </div>

    <div class="stat-card">
      <span class="stat">Nom étudiant (a modifier)</span>
      <span class="stat-value">à modifier</span>
    </div>

</div>
</body>
</html>
