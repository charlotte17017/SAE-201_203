<?php
session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Signalement Étudiant</title>
    <link rel="stylesheet" href="signalement.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@700;800&family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body>

  <nav class="navbar">
    <div class="nav-logo">
      <img src="logo.png" alt="Logo" class="footer-logo">
    </div>
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="offres.php">Offres de stage</a></li>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="convention.php">Mon stage</a></li>
      <li><a href="evaluation.php">Mes évaluations</a></li>
      <li><a href="signalement.php" class="active">Signaler un problème</a></li>
      <li><a href="historique.php">Historique</a></li>
    </ul>
    <div class="sidebar-user">
      <div class="user-name"></div><div><?php echo $_SESSION['prenom'] . ' ' . $_SESSION['nom']; ?></div>
      <div class="user-role">Étudiant MMI</div>
    </div>
  </aside>

  <div class="main">
    <div class="card">
      <div class="card-title">Signaler un problème</div>
      <div class="form-group">

        <div class="form-row">
          <div class="form-field">
            <label class="form-label">Prénom :</label>
            <input type="text" class="form-input" placeholder="Votre prénom" />
          </div>
          <div class="form-field">
            <label class="form-label">Nom :</label>
            <input type="text" class="form-input" placeholder="Votre nom" />
          </div>
        </div>

        <label class="form-label">Date du problème :</label>
        <input type="date" class="form-input" />

        <label class="form-label">Description :</label>
        <textarea class="form-textarea" placeholder="Décrivez votre problème..." style="height:100px; resize:none;"></textarea>
      </div>
      <button type="submit" class="btn-primary">Envoyer le signalement</button>
    </div>
  </div>

</body>
</html>