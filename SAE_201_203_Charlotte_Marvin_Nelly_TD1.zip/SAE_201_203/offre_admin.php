<?php

session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true){
    header("location: connexion.html");
    exit();
}

require 'bdd.php';


if(isset($_POST['action']) && $_POST['action'] === 'ajouter') {
  $titre = $_POST['Titre'];
  $nom_entreprise = $_POST['entreprise'];
  $lieu = $_POST['Lieu'];
  $duree = $_POST['duree'];
  $description = $_POST['description'];
  $date_publication = date("Y-m-d");

  $req = $bdd->prepare("INSERT INTO offres_stages (intitule, entreprise, lieu, duree, description , date_publication) VALUES (?, ?, ? ,?, ?, ?)");
  $req->execute([$titre,$nom_entreprise, $lieu, $duree, $description , $date_publication]);

$req_entreprise=$bdd->prepare("INSERT INTO entreprise (nom , adresse) VALUES (?, '-')
ON DUPLICATE KEY UPDATE nom = nom");
$req_entreprise->execute([$nom_entreprise]);



  header("location: offre_admin.php");
  exit();
}

if(isset($_POST['action']) && $_POST['action'] === 'supprimer') {
  $id_offre = $_POST['id_offre'];
  $req = $bdd->prepare("DELETE FROM offres_stages WHERE id = ?");
  $req->execute([$id_offre]);

  header("location: offre_admin.php");
  exit();
}

$req =$bdd->prepare("SELECT * FROM offres_stages");
$req->execute();
$stages = $req->fetchAll();

?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Offres de stage</title>
    <link rel="stylesheet" href="offre_admin.css">
</head>
<body>

  <nav class="navbar">
    <img src="logo.png" alt="Logo" class="footer-logo">
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="Dashboard_admin.php">Dashboard</a></li>
      <li><a href="offre_admin.php" class="active">Offres de stage</a></li>
      <li><a href="convention_admin.php">Convention</a></li>
      <li><a href="utilisateurs_admin.php">Utilisateurs</a></li>
    </ul>
    <div class="sidebar-user">
      <div class="user-info">
        <div class="user-name"><?php echo $_SESSION['prenom'] . ' ' . $_SESSION['nom']; ?></div>
        <div class="user-role">Administrateur</div>
      </div>
    </div>
  </aside>

  <div class="main">
    <div class="topbar">
      <div class="topbar-title">Offres de stage</div>
    </div>

    <div class="card-2">
      <h3>Ajouter une offre</h3>
      <table class="table">
        <thead>
          <tr>
            <th>Titre</th>
            <th>Entreprise</th>
            <th>Lieu</th>
            <th>Durée</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($stages as $offre): ?>
          <tr>
            <td><?php echo $offre['intitule']; ?></td>
            <td><?php echo $offre['entreprise']; ?></td>
            <td><?php echo $offre['lieu']; ?></td>
            <td><?php echo $offre['duree']; ?></td>
            <td>
              <form action="offre_admin.php" method="post">
                <input type="hidden" name="id_offre" value="<?php echo $offre['id']; ?>">
                <button type="submit" name="action" value="supprimer" class="btn-supprimer">Supprimer</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="ajouter_offre">
      <div class="offre-card">
        <h2>Ajouter une offre</h2>
        <form action="offre_admin.php" method="post">
          <label for="titre">Titre</label>
          <input type="text" id="titre" name="Titre" placeholder="Ex: Graphiste" required>

          <label for="entreprise">Entreprise</label>
          <input type="text" id="entreprise" name="entreprise" placeholder="Ex: Nike" required>

          <label for="Lieu">Lieu</label>
          <input type="text" id="Lieu" name="Lieu" placeholder="Ex: Paris" required>

          <label for="duree">Durée</label>
          <input type="text" id="duree" name="duree" placeholder="Ex: 2 mois" required>

          <label for="description">Description</label>
          <textarea id="description" name="description" placeholder="Description de l'offre" required></textarea>

          <button type="submit" name="action" value="ajouter" class="btn-primary">Ajouter l'offre</button>
        </form>
      </div>
    </div>
  </div>

</body>
</html>