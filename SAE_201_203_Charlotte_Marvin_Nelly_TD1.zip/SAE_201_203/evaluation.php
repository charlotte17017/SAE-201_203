<?php
session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.html");
    exit();
}

$host = "localhost";
$dbname = "SAE-STAGE-MMI";
$user = "root";
$password = "root";

try {
    $pdo = new PDO("mysql:host=$host;port=8889;dbname=$dbname;charset=utf8", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

$matricule = $_SESSION['user_id'];

// Récupérer le stage
$stmt = $pdo->prepare("SELECT s.id FROM stage s WHERE s.matricule_etudiant = ?");
$stmt->execute([$matricule]);
$stage = $stmt->fetch(PDO::FETCH_ASSOC);
$id_stage = $stage['id'] ?? 0;

// Récupérer la soutenance
$stmt2 = $pdo->prepare("SELECT * FROM soutenance WHERE id_stage = ?");
$stmt2->execute([$id_stage]);
$soutenance = $stmt2->fetch(PDO::FETCH_ASSOC);

// Récupérer la visite
$stmt3 = $pdo->prepare("SELECT v.*, CONCAT(e.prenom, ' ', e.nom) AS enseignant_nom 
                         FROM visite_suivi v
                         LEFT JOIN enseignants e ON e.id = v.id_enseignant
                         WHERE v.id_stage = ? 
                         ORDER BY v.date_visite DESC LIMIT 1");
$stmt3->execute([$id_stage]);
$visite = $stmt3->fetch(PDO::FETCH_ASSOC);

// Récupérer le jury
$stmt4 = $pdo->prepare("SELECT j.fonction AS jury_nom 
                         FROM composer_jury cj
                         LEFT JOIN jurys j ON j.id = cj.id_jury
                         WHERE cj.id_stage = ?");
$stmt4->execute([$id_stage]);
$jury = $stmt4->fetchAll(PDO::FETCH_ASSOC);

$note_rapport = $soutenance['note_rapport'] ? number_format($soutenance['note_rapport'], 2) : 'Non renseignée';
$note_oral = $soutenance['note_oral'] ? number_format($soutenance['note_oral'], 2) : 'Non renseignée';
$note_finale = $soutenance['note_finale'] ? number_format($soutenance['note_finale'], 2) : 'Non renseignée';
$date_soutenance = $soutenance['date_soutenance'] ? date('d/m/Y', strtotime($soutenance['date_soutenance'])) : '';
$commentaire_rapport = $soutenance['commentaire_rapport'] ?? '';
$commentaire_oral = $soutenance['oral'] ?? '';
$date_visite = $visite['date_visite'] ? date('d/m/Y', strtotime($visite['date_visite'])) : '';
$enseignant_nom = $visite['enseignant_nom'] ?? 'Non renseigné';
$rapport_visite = $visite['rapport'] ?? '';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Évaluations</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="evaluation.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@700;800&family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body>

  <nav class="navbar">
    <div class="nav-logo">
      <img src="logo.png" alt="Logo" class="footer-logo">
    </div>
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="offres.php">Offres de stage</a></li>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="convention.php">Mon stage</a></li>
      <li><a href="evaluation.php" class="active">Mes évaluations</a></li>
      <li><a href="signalement.php">Signaler un problème</a></li>
      <li><a href="historique.php">Historique</a></li>
    </ul>
    <div class="sidebar-user">
      <div class="user-name"><?php echo $_SESSION['prenom'] . ' ' . $_SESSION['nom']; ?></div>
      <p class="user-role">Étudiant MMI</p>
    </div>
  </aside>

  <div class="main">
    <div class="topbar">
      <div class="topbar-title">Évaluations</div>
    </div>

    <div class="notes-card">
      <div class="card-1">
        <h4>Note rapport</h4>
        <div class="note-rapport">
          <div class="note"><?php echo $note_rapport; ?></div>
          <div class="note-max">/20</div>
        </div>
      </div>

      <div class="card-2">
        <h4>Note oral</h4>
        <div class="note-rapport">
          <div class="note"><?php echo $note_oral; ?></div>
          <div class="note-max">/20</div>
        </div>
      </div>

      <div class="card-3">
        <h4>Note finale</h4>
        <div class="note-rapport">
          <div class="note"><?php echo $note_finale; ?></div>
          <div class="note-max">/20</div>
        </div>
      </div>

      <div class="card-4">
        <h4>Jury</h4>
        <div class="jury-list">
          <?php if (!empty($jury)): ?>
            <?php foreach ($jury as $membre): ?>
              <div class="jury-member"><?php echo $membre['jury_nom']; ?></div>
            <?php endforeach; ?>
          <?php else: ?>
            <div class="jury-member">Non renseigné</div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <div class="grid-1">
      <div class="grid-title">Soutenance</div>
      <div class="form-row">
        <label>Date</label>
        <span><?php echo $date_soutenance ?: 'Non renseignée'; ?></span>
      </div>
      <div class="form-row">
        <label>Commentaire rapport</label>
        <span><?php echo $commentaire_rapport ?: 'Non renseigné'; ?></span>
      </div>
      <div class="form-row">
        <label>Commentaire oral</label>
        <span><?php echo $commentaire_oral ?: 'Non renseigné'; ?></span>
      </div>
    </div>

    <div class="grid-2">
      <div class="grid-title">Visite de suivi</div>
      <div class="form-row">
        <label>Date</label>
        <span><?php echo $date_visite ?: 'Non renseignée'; ?></span>
      </div>
      <div class="form-row">
        <label>Enseignant</label>
        <span><?php echo $enseignant_nom; ?></span>
      </div>
      <div class="form-row">
        <label>Rapport</label>
        <span><?php echo $rapport_visite ?: 'Non renseigné'; ?></span>
      </div>
    </div>

  </div>

</body>
</html>