<?php
require 'connexion.php';

$matricule = $_POST["matricule"];
$nom = $_POST["nom"];
$prenom = $_POST["prenom"];
$email = $_POST['email'];
$password = $_POST['password'];
$role = $_POST['role'];

try {
    if ($role === 'etudiant') {
        $stmt = $bdd->prepare("SELECT matricule FROM etudiant WHERE adresse_email = ?");
        $stmt->execute([$email]);
        if ($stmt->rowCount() > 0) {
            echo "Email déjà utilisé";
            exit;
        }
        $stmt = $bdd->prepare("INSERT INTO etudiant (matricule, nom, prenom, adresse_email, mot_de_passe, est_valide) VALUES (?, ?, ?, ?, ?, FALSE)");
        $stmt->execute([$matricule, $nom, $prenom, $email, $password]);

    } else if ($role === 'enseignant') {
        $stmt = $bdd->prepare("SELECT id FROM enseignants WHERE adresse_email = ?");
        $stmt->execute([$email]);
        if ($stmt->rowCount() > 0) {
            echo "Email déjà utilisé";
            exit;
        }
        $stmt = $bdd->prepare("INSERT INTO enseignants (nom, prenom, adresse_email, mot_de_passe) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nom, $prenom, $email, $password]);

    } else if ($role === 'admin') {
        $stmt = $bdd->prepare("SELECT id FROM administrateur WHERE adresse_email = ?");
        $stmt->execute([$email]);
        if ($stmt->rowCount() > 0) {
            echo "Email déjà utilisé";
            exit;
        }
        $stmt = $bdd->prepare("INSERT INTO administrateur (nom, prenom, adresse_email, mot_de_passe) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nom, $prenom, $email, $password]);
    }

    header("Location: connexion.html");
    exit();

} catch(PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}
?>