<?php
session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.php");
    exit();
}

require 'bdd.php';

$stmt = $bdd->prepare("
    SELECT e.nom, e.prenom, e.promotion, s.sujet
    FROM etudiant e
    JOIN stage s ON s.matricule_etudiant = e.matricule
    ORDER BY e.nom
");
$stmt->execute();
$stagiaires = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes stagiaires</title>
    <link rel="stylesheet" href="stagiaires.css">
</head>
<body>

  <nav class="navbar">
    <img src="logo.png" alt="Logo" class="footer-logo">
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="dashboard_enseignant.php">Dashboard</a></li>
      <li><a href="stagiaires.php" class="active">Mes stagiaires</a></li>
      <li><a href="visite.php">Visites de suivi</a></li>
      <li><a href="evaluation_enseignant.php">Évaluations</a></li>
      <li><a href="problemes_enseignant.php">Problèmes signalés</a></li>
    </ul>
    <div class="sidebar-user">
      <div class="user-info">
        <div class="user-name"><?= htmlspecialchars($_SESSION['prenom'] . ' ' . $_SESSION['nom']) ?></div>
        <div class="user-role">Enseignant</div>
      </div>
    </div>
  </aside>

  <div class="main">
    <h1>Mes stagiaires</h1>
    <p>Voici un aperçu du suivi de vos étudiants en stage.</p>
    <div class="topbar">
      <span class="topbar-info">Année 2025-2026</span>
    </div>

    <div class="stats">
      <?php if (empty($stagiaires)): ?>
        <p style="color: var(--gris-texte);">Aucun stagiaire pour le moment.</p>
      <?php else: ?>
        <?php foreach ($stagiaires as $s): ?>
        <div class="stat-card">
          <span class="stat"><?= htmlspecialchars($s['prenom'] . ' ' . $s['nom']) ?></span>
          <span class="stat-value"><?= htmlspecialchars($s['sujet']) ?></span>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

</body>
</html>