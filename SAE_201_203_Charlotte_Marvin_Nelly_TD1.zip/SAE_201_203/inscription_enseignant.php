<?php

require 'connexion.php';

$nom = $_POST["nom"];
$prenom = $_POST["prenom"];
$email = $_POST['email'];
$password = $_POST['password'];

$stmt = $bdd->prepare("SELECT id FROM enseignants WHERE adresse_email = ?");
$stmt->execute([$email]);


if($stmt->rowCount() > 0){
echo "Email déjà utilisé";
exit;
}

$fonction_defaut = "Enseignant";
$stmt = $bdd->prepare("INSERT INTO  enseignants ( nom , prenom , adresse_email , mot_de_passe , fonction , ) 
                        VALUES (?, ?, ?, ?, ?, ?, FALSE)");
$stmt->execute([$nom, $prenom, $email, $password , $fonction_defaut]);

header("location: connexion.html");
exit();
?>

 <div class="sidebar-logo">
      <img src="logo.png" alt="Logo" class="footer-logo">
    </div>
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>