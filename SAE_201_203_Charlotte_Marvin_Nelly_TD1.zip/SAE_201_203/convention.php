<?php
session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.php");
    exit();
}

$host = "localhost";
$dbname = "SAE-STAGE-MMI";
$user = "root";
$password = "root";

try {
    $pdo = new PDO("mysql:host=$host;port=8889;dbname=$dbname;charset=utf8", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

$matricule = $_SESSION['user_id'];

// Récupérer le stage + entreprise + maitre de stage
$stmt = $pdo->prepare("SELECT s.*, e.nom AS entreprise_nom, e.adresse AS entreprise_adresse,
                        ms.nom AS maitre_nom, ms.prenom AS maitre_prenom, 
                        ms.telephone AS maitre_tel, ms.poste AS maitre_poste
                        FROM stage s
                        LEFT JOIN entreprise e ON e.id = s.id_offre
                        LEFT JOIN maitre_stage ms ON ms.id = s.id_maitre_stage
                        WHERE s.matricule_etudiant = ?");
$stmt->execute([$matricule]);
$stage = $stmt->fetch(PDO::FETCH_ASSOC);

// Calculer la durée
$duree = 'Non renseignée';
if ($stage && $stage['date_debut'] && $stage['date_fin']) {
    $debut = new DateTime($stage['date_debut']);
    $fin = new DateTime($stage['date_fin']);
    $mois = $debut->diff($fin)->m + ($debut->diff($fin)->y * 12);
$duree = $mois . ' mois';
}

$convention = $stage['convention'] ?? 'Non renseigné';
$date_debut = $stage['date_debut'] ? date('d/m/Y', strtotime($stage['date_debut'])) : 'Non renseignée';
$date_fin = $stage['date_fin'] ? date('d/m/Y', strtotime($stage['date_fin'])) : 'Non renseignée';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon stage</title>
    <link rel="stylesheet" href="convention.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@700;800&family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body>

  <nav class="navbar">
    <div class="nav-logo">
      <img src="logo.png" alt="Logo" class="footer-logo">
    </div>
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="offres.php">Offres de stage</a></li>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="convention.php" class="active">Mon stage</a></li>
      <li><a href="evaluation.php">Mes évaluations</a></li>
      <li><a href="signalement.php">Signaler un problème</a></li>
      <li><a href="historique.php">Historique</a></li>
    </ul>
    <div class="sidebar-user">
      <div class="user-info">
        <div class="user-name"><?php echo $_SESSION['prenom']." ".$_SESSION['nom']; ?></div>
        <div class="user-role">Étudiant MMI</div>
      </div>
    </div>
  </aside>

  <main class="main">

    <div class="topbar">
      <h1 class="topbar-title">Mon stage</h1>
    </div>

    <p>Détails de ma convention de stage :</p>

    <div class="convention-statut">
  <div class="statut-text"><h3>Convention <?php echo $convention; ?></h3></div>
</div>

    <div class="grid-2">
      <div class="card">
        <div class="card-title">Information sur l'entreprise</div>
        <div class="info-card">
          <p class="info-label">Nom de l'entreprise</p>
          <p class="info-value"><?php echo $stage['entreprise_nom'] ?? 'Non renseigné'; ?></p>
        </div>
        <div class="info-card">
          <p class="info-label">Sujet :</p>
          <p class="info-value"><?php echo $stage['sujet'] ?? 'Non renseigné'; ?></p>
        </div>
        <div class="info-card">
          <p class="info-label">Date de début :</p>
          <p class="info-value"><?php echo $date_debut; ?></p>
        </div>
        <div class="info-card">
          <p class="info-label">Date de fin :</p>
          <p class="info-value"><?php echo $date_fin; ?></p>
        </div>
        <div class="info-card">
          <p class="info-label">Durée :</p>
          <p class="info-value"><?php echo $duree; ?></p>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Etudiant</div>
        <div class="info-card">
          <p class="info-label">Nom :</p>
          <p class="info-value"><?php echo $_SESSION['nom']; ?></p>
        </div>
        <div class="info-card">
          <p class="info-label">Prénom :</p>
          <p class="info-value"><?php echo $_SESSION['prenom']; ?></p>
        </div>
        <div class="info-card">
          <p class="info-label">Maitre de stage :</p>
          <p class="info-value"><?php echo ($stage['maitre_nom'] ?? 'Non renseigné') . ' ' . ($stage['maitre_prenom'] ?? ''); ?></p>
        </div>
        <div class="info-card">
          <p class="info-label">Tuteur :</p>
          <p class="info-value"><?php echo $stage['maitre_poste'] ?? 'Non renseigné'; ?></p>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Maitre de stage</div>
      <div class="grid-3">
        <div class="info-grid-3">
          <p class="info-cul-label">Nom :</p>
          <p class="info-cul-value"><?php echo $stage['maitre_nom'] ?? 'Non renseigné'; ?></p>
        </div>
        <div class="info-grid-3">
          <p class="info-cul-label">Prénom :</p>
          <p class="info-cul-value"><?php echo $stage['maitre_prenom'] ?? 'Non renseigné'; ?></p>
        </div>
        <div class="info-grid-3">
          <p class="info-cul-label">Poste :</p>
          <p class="info-cul-value"><?php echo $stage['maitre_poste'] ?? 'Non renseigné'; ?></p>
        </div>
        <div class="info-grid-3">
          <p class="info-cul-label">Téléphone :</p>
          <p class="info-cul-value"><?php echo $stage['maitre_tel'] ?? 'Non renseigné'; ?></p>
        </div>
      </div>
    </div>

  </main>

</body>
</html>