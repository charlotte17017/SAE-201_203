<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'bdd.php';


$email = $_POST['email'];
$password = $_POST['password'];
$role = $_POST['role'];

try {

    if ($role === 'etudiant') {
        $stmt = $bdd->prepare("SELECT * FROM etudiant WHERE adresse_email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && $password === $user['mot_de_passe']) {
            $_SESSION['connecte'] = true;
            $_SESSION['role'] = $role;
            $_SESSION['nom'] = isset($user['nom']) ? $user['nom'] : '';
            $_SESSION['prenom'] = isset($user['prenom']) ? $user['prenom'] : '';
            $_SESSION['user_id'] = isset($user['matricule']) ? $user['matricule'] : '';
            header("Location: offres.php");
            exit();
        }

    } else if ($role === 'admin') {
        $stmt = $bdd->prepare("SELECT * FROM administrateur WHERE adresse_email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && $password === $user['mot_de_passe']) {
            $_SESSION['connecte'] = true;
            $_SESSION['role'] = 'admin';
            $_SESSION['nom'] = isset($user['nom']) ? $user['nom'] : '';
            $_SESSION['prenom'] = isset($user['prenom']) ? $user['prenom'] : '';
            $_SESSION['user_id'] = isset($user['id']) ? $user['id'] : '';
            header("Location: dashboard_admin.php");
            exit();
        }

    } else if ($role === 'enseignant') {
        $stmt = $bdd->prepare("SELECT * FROM enseignants WHERE adresse_email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && $password === $user['mot_de_passe']) {
            $_SESSION['connecte'] = true;
            $_SESSION['role'] = 'enseignant';
            $_SESSION['nom'] = isset($user['nom']) ? $user['nom'] : '';
            $_SESSION['prenom'] = isset($user['prenom']) ? $user['prenom'] : '';
            $_SESSION['user_id'] = isset($user['id']) ? $user['id'] : '';
            header("Location: dashboard_enseignant.php");
            exit();
        }
    }

    echo "Email, mot de passe ou rôle incorrect. <a href='connexion.php'>Réessayer</a>";

} catch(PDOException $e) {
    echo "Erreur lors de la connexion : " . $e->getMessage();
}
?>

