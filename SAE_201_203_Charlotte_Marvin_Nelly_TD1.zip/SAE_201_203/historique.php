<?php
session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.php");
    exit();
}

require 'bdd.php';

$matricule = $_SESSION['user_id'];

$stmt = $bdd->prepare("SELECT * FROM historique WHERE matricule_etudiant = ? AND action = 'offre_consultee' ORDER BY date_historique DESC");
$stmt->execute([$matricule]);
$offres_consultees = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt2 = $bdd->prepare("SELECT s.sujet, s.date_debut, s.date_fin, e.nom AS entreprise_nom
                         FROM stage s
                         LEFT JOIN entreprise e ON e.id = s.id_offre
                         WHERE s.matricule_etudiant = ?");
$stmt2->execute([$matricule]);
$stages = $stmt2->fetchAll(PDO::FETCH_ASSOC);

$stmt3 = $bdd->prepare("SELECT * FROM problemes WHERE id_stage IN (SELECT id FROM stage WHERE matricule_etudiant = ?) ORDER BY date_probleme DESC");
$stmt3->execute([$matricule]);
$problemes = $stmt3->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Historique</title>
    <link rel="stylesheet" href="historique.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@700;800&family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body>

  <nav class="navbar">
    <div class="nav-logo">
      <img src="logo.png" alt="Logo" class="footer-logo">
    </div>
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="offres.php">Offres de stage</a></li>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="convention.php">Mon stage</a></li>
      <li><a href="evaluation.php">Mes évaluations</a></li>
      <li><a href="signalement.php">Signaler un problème</a></li>
      <li><a href="historique.php" class="active">Historique</a></li>
    </ul>
    <div class="sidebar-user">
      <div class="user-name"><?php echo $_SESSION['prenom'] . ' ' . $_SESSION['nom']; ?></div>
      <div class="user-role">Étudiant MMI</div>
    </div>
  </aside>

  <div class="main">
    <div class="topbar">
      <span class="topbar-title">Historique</span>
    </div>

    <div class="section-title">Offres consultées</div>
    <?php if (empty($offres_consultees)): ?>
      <p class="empty">Aucune offre consultée.</p>
    <?php else: ?>
      <?php foreach ($offres_consultees as $offre): ?>
        <div class="hist-card">
          <div class="hist-left">
            <div>
              <p class="hist-label"><?php echo htmlspecialchars($offre['description']); ?></p>
              <p class="hist-sub">Consulté le <?php echo date('d/m/Y', strtotime($offre['date_historique'])); ?></p>
            </div>
          </div>
          <span class="badge b-blue">Consulté</span>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>

    <div class="section-title" style="margin-top: 2rem;">Stages effectués</div>
    <?php if (empty($stages)): ?>
      <p class="empty">Aucun stage effectué.</p>
    <?php else: ?>
      <?php foreach ($stages as $stage): ?>
        <div class="hist-card">
          <div class="hist-left">
            <div>
              <p class="hist-label"><?php echo htmlspecialchars($stage['sujet']); ?> — <?php echo htmlspecialchars($stage['entreprise_nom'] ?? 'Non renseigné'); ?></p>
              <p class="hist-sub"><?php echo date('d/m/Y', strtotime($stage['date_debut'])); ?> → <?php echo date('d/m/Y', strtotime($stage['date_fin'])); ?></p>
            </div>
          </div>
          <span class="badge b-green">Terminé</span>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>

    <div class="section-title" style="margin-top: 2rem;">Problèmes signalés</div>
    <?php if (empty($problemes)): ?>
      <p class="empty">Aucun problème signalé.</p>
    <?php else: ?>
      <?php foreach ($problemes as $probleme): ?>
        <div class="hist-card">
          <div class="hist-left">
            <div>
              <p class="hist-label"><?php echo htmlspecialchars($probleme['description']); ?></p>
              <p class="hist-sub">Signalé le <?php echo date('d/m/Y', strtotime($probleme['date_probleme'])); ?></p>
            </div>
          </div>
          <span class="badge b-amber">En attente</span>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>

  </div>

</body>
</html>