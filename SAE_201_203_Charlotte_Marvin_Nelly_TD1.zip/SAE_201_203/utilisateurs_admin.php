
<?php
session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.php");
    exit();
}

require 'bdd.php';

$stmt_etudiants = $bdd->prepare("SELECT matricule, nom, prenom, promotion FROM etudiant ORDER BY nom");
$stmt_etudiants->execute();
$etudiants = $stmt_etudiants->fetchAll(PDO::FETCH_ASSOC);

$stmt_enseignants = $bdd->prepare("SELECT id, nom, prenom, fonction FROM enseignants ORDER BY nom");
$stmt_enseignants->execute();
$enseignants = $stmt_enseignants->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Stagiaires</title>
    <link rel="stylesheet" href="utilisateurs_admin.css">
</head>
<body>

  <nav class="navbar">
    <img src="logo.png" alt="Logo" class="footer-logo">
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="dashboard_admin.php">Dashboard</a></li>
      <li><a href="offre_admin.php">Offres de stage</a></li>
      <li><a href="convention_admin.php">Convention</a></li>
      <li><a href="utilisateurs_admin.php" class="active">Utilisateurs</a></li>
    </ul>
    <div class="sidebar-user">
      <div class="user-info">
        <div class="user-name"><?= htmlspecialchars($_SESSION['prenom'] . ' ' . $_SESSION['nom']) ?></div>
        <div class="user-role">Administrateur</div>
      </div>
    </div>
  </aside>

  <div class="main">
    <h1>Utilisateur</h1>
    <p>Voici un aperçu de l'ensemble des utilisateurs.</p>
    <div class="topbar">
      <span class="topbar-info"></span>
    </div>

    <div class="stats">
      <?php foreach ($etudiants as $e): ?>
      <div class="stat-card">
        <span class="stat">Etudiant</span>
        <span class="stat-value"><?= htmlspecialchars($e['prenom'] . ' ' . $e['nom']) ?></span>
      </div>
      <?php endforeach; ?>
    </div>

    <div class="quick-actions">
      <?php foreach ($enseignants as $ens): ?>
      <div class="quick-action">
        <div class="stat">Enseignant</div>
        <span class="stat-value"><?= htmlspecialchars($ens['prenom'] . ' ' . $ens['nom']) ?></span>
      </div>
      <?php endforeach; ?>
    </div>

  </div>

</body>
</html>