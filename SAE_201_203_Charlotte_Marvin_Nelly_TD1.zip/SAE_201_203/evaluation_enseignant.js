

const noteRapport = document.getElementById ("note");
const noteOral = document.getElementById("note_oral");
const noteFinale = document.getElementById("note_finale");

const calculMoyenne = () => {
    const rapport = parseFloat(noteRapport.value);
    const oral = parseFloat(noteOral.value);


if(isNaN(rapport) || isNaN(oral)){
    noteFinale.value = '';
    return;
}

const moyenne = (rapport + oral ) / 2;

noteFinale.value = moyenne.toFixed(2);

};

noteRapport.addEventListener('input', calculMoyenne);
noteOral.addEventListener('input', calculMoyenne);

