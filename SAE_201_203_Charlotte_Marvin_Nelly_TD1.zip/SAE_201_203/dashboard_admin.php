



<?php

session_start();
if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("location: connexion.html");
    exit();
}

require 'bdd.php';


try {
    $req = $bdd-> prepare("SELECT COUNT(*) as total FROM etudiant");
    $req->execute();
    $nb_etudiants = $req->fetch()['total'];

    $req = $bdd-> prepare("SELECT COUNT(*) as total FROM stage");
    $req->execute();
    $nb_stage = $req->fetch()['total'];

    $req = $bdd-> prepare("SELECT COUNT(*) as total FROM problemes ");
    $req->execute();
    $nb_signalement = $req->fetch()['total'];

    $req = $bdd-> prepare("SELECT COUNT(*) as total FROM offres_stages");
    $req->execute();
    $nb_offre = $req->fetch()['total'];

    $req = $bdd-> prepare("SELECT COUNT(*) as total FROM etudiant");
    $req->execute();
    $nb_offre = $req->fetch()['total'];




} catch (PDOException $e) {
    echo "Erreur lors de la connexion : " . $e->getMessage();
}



?>



<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>

  <nav class="navbar">
    <img src="logo.png" alt="Université Gustave Eiffel" class="footer-logo">
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="dashboard_admin.php" class="active">Dashboard</a></li>
      <li><a href="offre_admin.php">Offres de stage</a></li>
      <li><a href="convention_admin.php">Convention</a></li>
      <li><a href="utilisateurs_admin.php">Utilisateurs</a></li>
    </ul>

    <div class="sidebar-footer">
      <div class="user-name"><?php echo $_SESSION['prenom']." ".$_SESSION['nom']; ?></div>
      <div class="user-role">Administrateur</div>
    </div>
  </aside>

  <div class="main">
    <div class="topbar">
      <span class="topbar-title">Dashboard</span>
      <span class="topbar-info">Année 2025-2026</span>
    </div>

    <div class="content">

      <div class="Bannière">
        <div>
          <h2>Bienvenue, <?php echo $_SESSION['prenom']." ".$_SESSION['nom']; ?></h2>
          <p>Voici un aperçu de vos activités récentes et de vos statistiques.</p>
        </div>
      </div>

      <div class="stats">
        <div class="stat-card">
          <span class="stat">Nombre d'étudiants</span>
          <span class="stat-value"><?php echo $nb_etudiants; ?></span>
        </div>
        <div class="stat-card">
          <span class="stat">Nombres de stage</span>
          <span class="stat-value"><?php echo $nb_stage; ?></span>
        </div>
        <div class="stat-card">
          <span class="stat">Inscriptions</span>
          <span class="stat-value"><?php echo $nb_etudiants; ?></span>
        </div>
      </div>

      <div class="quick-actions">
        <a href="offre_admin.php" class="quick-action">
          <div class="stat">Offres de stage</div>
          <span class="stat-value"><?php echo $nb_offre; ?></span>
        </a>
        <a href="offre_admin.php" class="quick-action">
          <div class="stat">Gérer les offres</div>
          <span class="stat-value"><?php echo $nb_offre; ?></span>
        </a>
        <a href="signalement_enseignant.html" class="quick-action">
          <div class="stat">Problèmes traités</div>
          <span class="stat-value"><?php echo $nb_signalement; ?></span>
        </a>
      </div>

    </div>
  </div>

</body>
</html>