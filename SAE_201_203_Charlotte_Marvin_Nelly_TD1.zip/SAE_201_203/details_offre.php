<?php
session_start();

if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    header("Location: connexion.php");
    exit();
}

require 'bdd.php';

$id = $_GET['id'] ?? 0;

$stmt = $bdd->prepare("SELECT * FROM offres_stages WHERE id = ?");
$stmt->execute([$id]);
$offre = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$offre) {
    header("Location: offres.php");
    exit();
}
?>

<!doctype html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title><?php echo htmlspecialchars($offre['intitule']); ?></title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="offres.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@700;800&family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body>

  <nav class="navbar">
    <div class="nav-logo">
      <img src="logo.png" alt="Logo" class="footer-logo">
    </div>
    <a href="deconnexion.php" class="btn-nav">Déconnexion</a>
  </nav>

  <aside class="sidebar">
    <ul class="sidebar-nav">
      <li><a href="offres.php" class="active">Offres de stage</a></li>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="convention.php">Mon stage</a></li>
      <li><a href="evaluation.php">Mes évaluations</a></li>
      <li><a href="signalement.php">Signaler un problème</a></li>
      <li><a href="historique.php">Historique</a></li>
    </ul>
    <div class="sidebar-user">
      <div class="user-name"><?php echo htmlspecialchars($_SESSION['prenom'] . ' ' . $_SESSION['nom']); ?></div>
      <div class="user-role">Étudiant MMI</div>
    </div>
  </aside>

  <main class="main">
    <div class="topbar">
      <a href="offres.php" class="btn-retour">Retour aux offres</a>
    </div>

    <div class="detail-card">

      <div class="detail-header">
        <div>
          <h1 class="topbar-title"><?php echo htmlspecialchars($offre['intitule']); ?></h1>
          <p class="company"><?php echo htmlspecialchars($offre['entreprise']); ?></p>
        </div>
        <span class="salary"><?php echo $offre['remuneration'] ? htmlspecialchars($offre['remuneration']) . '€/mois' : 'Non renseignée'; ?></span>
      </div>

      <div class="detail-meta">
        <span><?php echo htmlspecialchars($offre['lieu']); ?></span>
        <span><?php echo htmlspecialchars($offre['duree']); ?></span>
        <span>Publié le <?php echo date('d/m/Y', strtotime($offre['date_publication'])); ?></span>
      </div>

      <div class="tags" style="margin: 20px 0;">
        <?php 
          if ($offre['competences']) {
            $tags = explode(',', $offre['competences']);
            foreach ($tags as $tag) {
              echo '<span class="tag">' . htmlspecialchars(trim($tag)) . '</span>';
            }
          }
        ?>
      </div>

      <div class="detail-section">
        <h2>Description</h2>
        <p><?php echo htmlspecialchars($offre['description']); ?></p>
      </div>

      <div class="detail-footer">
        <span class="badge disponible">Disponible</span>
        <a href="offres.php" class="btn-voir">Postuler</a>
      </div>

    </div>
  </main>

</body>
</html>